

import pandas as pd
import gensim.downloader as api
from gensim.models import Word2Vec
import pandas as pd
from sklearn.manifold import TSNE
from sklearn.decomposition import IncrementalPCA
import gensim.models
import numpy as np
from gensim import utils
from gensim.test.utils import datapath
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
import nltk
from nltk import word_tokenize
from nltk.corpus import stopwords
from unidecode import unidecode
import string
import re
from collections import defaultdict
#Reads the dataset
df = pd.read_csv('data.csv')
df.head()
#downloads the stopwords list
nltk.download('stopwords')
#Takes the users input
user = input("Please write a description of your perfect holiday destination this may be as long or short as needed longer descriptions will turn out more accurate in the end")
print("please wait as the program finds your ideal location")
#turns the dataset reviews to a list format
df1 = df['city_review'].tolist()
#prepares the lemmatizing function
lemmatizer = nltk.stem.WordNetLemmatizer()
#creates a list of the cities with duplicates
cities = df['city'].tolist()
#sets all the reviews to lowercase
df1 = [x.lower() for x in df1]
#creates a dictionary
variables = {}
for f in range(len(df1)):
    #tockenizes each of the variables located in each position in the dataset
    variables[df.iloc[f, 2]] = word_tokenize(df1[f])
# creates a black array of cities
citiesDf = []
citieslist = []
valuePairs = []

for y in range(len(df1)):
    #if the city is not already in the blank array add it to the list
    if df.iloc[y,2] not in citiesDf:
        citiesDf.append(df.iloc[y,2])
        citieslist.append(df.iloc[y,2])

    else:
        #reverse the list of cities to get the last index
        citiesDf = list(reversed(citiesDf))
        position = citiesDf.index(df.iloc[y,2])
        #turn the list back to normal
        reverseCity = list(reversed(citiesDf))
        #use the position of the last index and the number of loops to find the missing review. -1 as the iteration and array counting are at different intervals.
        variables[df.iloc[y,2]] += word_tokenize(df1[y-(position)-1])
        #add the city to the list so it works for all the following cities
        citiesDf.append(df.iloc[y,2])

for w in range(len(variables)):
    valuePairs = list(variables.values())

newlist = []
for q in range(len(valuePairs)):
    #remove the stopwords from all of the dictionaries words but not the cities themselves
    newdesc = [word for word in valuePairs[q] if not word in stopwords.words()]
    stopset = stopwords.words('english') + list(string.punctuation)
    #remove the punctuation from the list as well
    newdesc = ["".join(i for i in s if i not in string.punctuation) for s in newdesc]
    newdesc = [s for s in newdesc if s]
    #lemmatize each of these words
    for m in range(len(newdesc)):
        newdesc[m] = lemmatizer.lemmatize(newdesc[m])
    #create a new list of just these words in the correct format
    newlist.append(newdesc)

#do the same for all of the users words
user = word_tokenize(user)
user = [word for word in user if not word in stopwords.words()]
stopset = stopwords.words('english') + list(string.punctuation)
user = ["".join(i for i in s if i not in string.punctuation) for s in user]
user = [s for s in user if s]
for l in range(len(user)):
    user[l] = lemmatizer.lemmatize(user[l])
newlist.append(user)

#prepare to put the words into the model
sentences = newlist
#put the words into the model
model = Word2Vec(sentences, min_count=1, size=50, workers=4, window=3, sg=1)
compare = []
#create a list of the most similar words to each word in the users list
for word in user:
    compare += [i[0] for i in model.most_similar(word)[:5]]
#create a list of scores for each city in the database
scorelist = [0]*len(citieslist)
for ahh in range(len(citieslist)):
    for wer in range(len(compare)):
        #give each city a score based on how many times the most similar word appears
        scorelist[ahh] += df1[ahh].count(compare[wer])/len(df1[ahh])
#sort and reverse the city list based on where the position of the scores are in the scorelist so the highest score is at the front but in string format
z = [citieslist for _,citieslist in sorted(zip(scorelist,citieslist), reverse=True)]
#print the top 3 cities
print("your top three cities based off your description are:\n", z[0], "\n", z[1], "\n", z[2])
#function to reduce the dimension of the model
def reduce_dimensions(model):
    #sets 2 dimensions
    num_dimensions = 2
    vectors = []
    labels = []
    #adds each word in the vocabulary list based on their vectors
    for word in model.wv.vocab:
        vectors.append(model.wv[word])


        labels.append(word)
    vectors = np.asarray(vectors)
    labels = np.asarray(labels)
    vectors = np.asarray(vectors)
    tsne = TSNE(n_components=num_dimensions, random_state=0)
    vectors = tsne.fit_transform(vectors)
    x_vals = [v[0] for v in vectors]
    y_vals = [v[1] for v in vectors]


    return x_vals, y_vals, labels
x_vals, y_vals, labels = reduce_dimensions(model)
#plots each of the points in the reduced dimensions model
def plot_with_plotly(x_vals, y_vals, labels, plot_in_notebook=True):
    from plotly.offline import init_notebook_mode, iplot, plot
    import plotly.graph_objs as go

    trace = go.Scatter(x=x_vals, y=y_vals, mode='text', text=labels)
    data = [trace]

    if plot_in_notebook:
        init_notebook_mode(connected=True)
        iplot(data, filename='word-embedding-plot')
    else:
        plot(data, filename='word-embedding-plot.html')

def plot_with_matplotlib(x_vals, y_vals, labels):
    import matplotlib.pyplot as plt
    import random
    random.seed(0)

    plt.figure(figsize=(24, 24))
    plt.scatter(x_vals, y_vals)

    indices = list(range(len(labels)))
    selected_indices = random.sample(indices, 20)
    for i in selected_indices:


        plt.annotate(labels[i], (x_vals[i], y_vals[i]))

    plt.show()

try:
    get_ipython()
except Exception:
    plot_function = plot_with_matplotlib
else:
    plot_function = plot_with_plotly
#shows the plotted function
plot_function(x_vals, y_vals, labels)

